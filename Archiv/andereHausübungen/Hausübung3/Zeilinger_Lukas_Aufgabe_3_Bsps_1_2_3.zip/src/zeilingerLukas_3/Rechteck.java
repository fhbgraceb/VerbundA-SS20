package zeilingerLukas_3;

import java.util.Scanner;

public class Rechteck 
{

	public static void main(String[] args) 
	{
		double a = 0;
		double b = 0;
		double umfang = 0;
		double flaeche = 0;
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Geben Sie a ein: ");
		a = scan.nextDouble();
		System.out.println("Geben Sie b ein: ");
		b = scan.nextDouble();
		
		umfang = berechneUmfang(a,b);
		flaeche = berechneFläche(a,b);
		
		System.out.println("Umfang: " + umfang);
		System.out.println("Flaeche: " + flaeche);
	}
	public static double berechneUmfang (double a, double b)
	{
		double umfang = 0;
		umfang = (2*a)+(2*b);
		return umfang;
	}
	public static double berechneFläche (double a, double b)
	{
		double flaeche = 0;
		flaeche = a*b;
		return flaeche;
	}

}
