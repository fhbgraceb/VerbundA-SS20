package zeilingerLukas_3;

import java.util.Scanner;

public class Kreis 
{

	public static void main(String[] args) 
	{
		double r = 0;
		double umfang = 0;
		double flaeche = 0;
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Geben Sie r ein: ");
		r = scan.nextDouble();
		
		umfang = berechneUmfang(r);
		flaeche = berechneFlaeche(r);
		
		umfang = Math.round((umfang)*1000f)/1000f;
		
		//System.out.println("Umfang: " + umfang);
		System.out.println("Umfang: " + Math.round((umfang)*1000f)/1000f);
		System.out.println("Flaeche: " + Math.round((flaeche)*1000f)/1000f);

	}
	public static double berechneUmfang (double r)
	{
		double umfang = 0;
		umfang = (2*Math.PI*r);
		return umfang;
	}
	public static double berechneFlaeche (double r)
	{
		double flaeche = 0;
		flaeche = Math.PI*Math.pow(r, 2);
		return flaeche;
	}

}
