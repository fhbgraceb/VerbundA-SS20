package zeilingerLukas_3;

import java.util.Scanner;

public class Schotterwagen 
{

	public static void main(String[] args) 
	{
		double leergewicht = 0;
		double gesamtgewicht = 0;
		double RohgewichtSäcke = 0;
		int azSaecke = 0;
		Scanner scanner = new Scanner(System.in); 
		
		System.out.println("Geben Sie das Leergewicht des LKWs an (kg): ");
		leergewicht = Double.parseDouble(scanner.next());
		System.out.println("Geben Sie das Gesamtgewicht des LKWs an (kg): ");
		gesamtgewicht = Double.parseDouble(scanner.next());
		
		azSaecke = AzSaeckeBerechnung(leergewicht,gesamtgewicht);
		System.out.println("Auf dem LKW sind " + azSaecke + " Säcke");
	}
	
	public static int AzSaeckeBerechnung(double leer, double ges)
	{
		double az = 0;
		int sackgewicht = 50;
		az = (ges-leer)/sackgewicht;
		az = Math.round(az);
		return (int)az;
	}

}
