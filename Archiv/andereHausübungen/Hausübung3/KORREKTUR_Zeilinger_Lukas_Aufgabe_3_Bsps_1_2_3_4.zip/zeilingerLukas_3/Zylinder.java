package zeilingerLukas_3;

import java.util.Scanner;

public class Zylinder 
{

	public static void main(String[] args) 
	{
		double r = 0;
		double h = 0;
		double oberflaeche = 0;
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Geben Sie r ein: ");
		r = scan.nextDouble();
		System.out.println("Geben Sie h ein: ");
		h = scan.nextDouble();
		
		oberflaeche = berechneOberflaeche(r,h);
		
		System.out.println("Oberflaeche: " + Math.round((oberflaeche)*1000f)/1000f);

	}
	public static double berechneOberflaeche (double r, double h)
	{
		double oberflaeche = 0;
		oberflaeche = 2* Math.PI * r *(r+h);
		return oberflaeche;
	}

}
