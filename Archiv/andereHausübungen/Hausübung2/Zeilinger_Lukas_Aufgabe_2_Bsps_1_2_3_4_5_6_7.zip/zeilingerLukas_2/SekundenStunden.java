package zeilingerLukas_2;

import java.util.Scanner;

public class SekundenStunden 
{

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		int sekunden;
		int stunden;
		int minuten;
		int umr = 60;
		
		System.out.println("Geben Sie Sekunden ein");
		sekunden = scan.nextInt();
		minuten = sekunden/umr;
		sekunden = sekunden - (minuten*umr);
		
		stunden = minuten/umr;
		minuten = minuten - (stunden*umr);
		
		System.out.println("Das sind "+stunden+" Stunden, "+minuten+" Minuten und "+sekunden+" Sekunden");

	}

}
