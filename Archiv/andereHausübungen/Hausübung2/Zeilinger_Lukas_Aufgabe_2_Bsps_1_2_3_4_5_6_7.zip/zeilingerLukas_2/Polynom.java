package zeilingerLukas_2;

import java.util.Scanner;

public class Polynom 
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		
		double x;
		double koeffizient;
		double ergebnis;
		
		System.out.println("Geben Sie x ein: ");
		x = scan.nextDouble();
		System.out.println("Geben Sie a ein");
		koeffizient = scan.nextDouble();
		ergebnis = Math.pow((koeffizient*x), 4);
		
		System.out.println("Geben Sie b ein");
		koeffizient = scan.nextDouble();
		ergebnis += Math.pow((koeffizient*x), 3);
		
		System.out.println("Geben Sie c ein");
		koeffizient = scan.nextDouble();
		ergebnis += Math.pow((koeffizient*x), 2);
		
		System.out.println("Geben Sie d ein");
		koeffizient = scan.nextDouble();
		ergebnis += (koeffizient*x);
		
		System.out.println("Geben Sie e ein");
		koeffizient = scan.nextDouble();
		ergebnis += koeffizient;
		
		System.out.println("Der der Stelle x="+x+" ist der y-Wert y="+ergebnis);;

	}
}
