package zeilingerLukas_2;

import java.util.Scanner;

public class Horner {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		double a;
		double b;
		double c;
		double x;
		double rest;
		double hb;
		double hc;
		
		System.out.println("Geben Sie a ein: ");
		a = scan.nextDouble();
		System.out.println("Geben Sie b ein: ");
		b = scan.nextDouble();
		System.out.println("Geben Sie c ein: ");
		c = scan.nextDouble();
		System.out.println("Geben Sie x ein: ");
		x = scan.nextDouble();
		
		hb = a;
		hc = hb*x+b;
		rest = hc*x+c;
		
		System.out.println("Nach dem Horner Schema ergibt das: " +hb + "x + "+hc +" "+" Rest: "+rest);
		

	}

}
