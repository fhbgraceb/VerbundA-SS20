package zeilingerLukas_2;

import java.util.Scanner;

public class Chemie 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		double gh2;
		double go2;
		double wasser;
		final double umr = 18.018; // g pro mol H2O
		final double molaremasseo2 = 31.998; //gramm pro Mol O2
		final double molaremasseh2 = 2.019489; // gramm Pro mol H2
		
		System.out.println("Wie viel Gramm Wasserstoff haben wir zur verfügung? : ");
		gh2 = scan.nextDouble();
		
		wasser = gh2/molaremasseh2*umr;
		go2 = (wasser/umr*2)*molaremasseo2;
		
		System.out.println("Ausgehend von "+(gh2)+" Gramm Wasserstoff, werden "+go2+" Gramm Sauerstoff benötigt, um "+wasser+" ml Wasser zu erhalten.");
		
	}

}
