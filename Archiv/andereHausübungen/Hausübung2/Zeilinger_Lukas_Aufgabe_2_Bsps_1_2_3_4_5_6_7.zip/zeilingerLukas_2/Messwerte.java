package zeilingerLukas_2;

import java.util.Scanner;

public class Messwerte 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		double Zahl1;
		double Zahl2;
		double Zahl3;
		double Zahl4;
		double Zahl5;
		double addieren;
		double mittelwert;
		int anzahl = 5;
		
		System.out.println("Geben Sie die 1. Zahl ein: ");
		Zahl1 = scan.nextInt();
		System.out.println("Geben Sie die 2. Zahl ein: ");
		Zahl2 = scan.nextInt();
		System.out.println("Geben Sie die 3. Zahl ein: ");
		Zahl3 = scan.nextInt();
		System.out.println("Geben Sie die 4. Zahl ein: ");
		Zahl4 = scan.nextInt();
		System.out.println("Geben Sie die 5. Zahl ein: ");
		Zahl5 = scan.nextInt();
		
		addieren = Zahl1 + Zahl2 + Zahl3 + Zahl4 + Zahl5;
		mittelwert = (double)addieren/anzahl;
		
		System.out.println("Der Mittelwert lautet: " +mittelwert);
		
		System.out.println("Geben Sie die 1. Zahl ein: ");
		Zahl1 = scan.nextInt();
		addieren = Zahl1;
		
		System.out.println("Geben Sie die 2. Zahl ein: ");
		Zahl1 = scan.nextInt();
		addieren += Zahl1;
		
		System.out.println("Geben Sie die 3. Zahl ein: ");
		Zahl1 = scan.nextInt();
		addieren += Zahl1;
		
		System.out.println("Geben Sie die 4. Zahl ein: ");
		Zahl1 = scan.nextInt();
		addieren += Zahl1;
		
		System.out.println("Geben Sie die 5. Zahl ein: ");
		Zahl1 = scan.nextInt();
		addieren += Zahl1;
		
		mittelwert = addieren/anzahl;
		System.out.println("Mittelwert mit der selben Variable " + mittelwert);

	}

}
