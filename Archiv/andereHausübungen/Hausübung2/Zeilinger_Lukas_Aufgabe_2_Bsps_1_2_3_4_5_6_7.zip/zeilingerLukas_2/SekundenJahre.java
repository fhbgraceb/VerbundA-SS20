package zeilingerLukas_2;

import java.util.Scanner;

public class SekundenJahre 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		long jahre;
		long monate;
		long tage;
		long stunden;
		long minuten;
		long sekunden;
		
		System.out.println("Geben Sie Sekunden ein: ");
		sekunden = scan.nextLong();
		
		minuten = sekunden/60;
		sekunden = sekunden - (minuten*60);
		
		stunden = minuten/60;
		minuten = minuten -(stunden*60);
		
		tage = stunden/24;
		stunden = stunden - (tage*24);
		
		monate = tage/30;
		tage = tage - (monate*30);
		
		jahre = monate/12;
		monate = monate -(jahre*12);
		
		System.out.println("Das sind "+jahre+" Jahre, "+monate+" Monate, "+tage+" Tage, "+stunden+" Stunden, "+minuten+" Minuten und "+sekunden+" Sekunden");

	}

}
