package zeilingerLukas_2;

import java.math.BigDecimal;

public class Lotto 
{
	public static void main(String[] args)
	{
		double gesamt = 45;
		double zahlen = 6;
		double ws;
		String wsstring;
		
		double möglichkeiten = Math.pow(gesamt, zahlen);
		ws = 1/möglichkeiten*100;
		wsstring = String.format("%.10f", ws);
		System.out.println("Die Wahrscheinlichkeit ist :" +wsstring+" %");

	}
}
