package Einheit04;

import java.util.Scanner;

public class Punkte {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner (System.in);
		int punkte = 0;
		int note = 0;
		String notenstring = "";
		
		System.out.println("Geben Sie die Punkte ein: ");
		punkte = scan.nextInt();
		
		note = Notenberechnung(punkte);
		notenstring = NotenText(note);
		
		System.out.println(notenstring);

	}
	
	public static int Notenberechnung (int punkte)
	{
		int note = 0;
		if(punkte <= 50) note = 5;
		else if(punkte >= 51 && punkte <= 62) note = 4;
		else if(punkte >= 63 && punkte <= 75) note = 3;
		else if(punkte >= 76 && punkte <= 88) note = 2;
		else if(punkte >= 89 && punkte <= 100) note = 1;
		else note = 0;
		
		return note;
	}
	public static String NotenText (int note)
	{
		String notentext = "";
		switch(note)
		{
		case 1: notentext = "Sehr Gut"; break;
		case 2: notentext = "Gut"; break;
		case 3: notentext = "Befriedigend"; break;
		case 4: notentext = "Genügend"; break;
		case 5: notentext = "Nicht Genügend"; break;
		case 0: notentext = "Ungültige Eingabe"; break;
		}
		return notentext;
	}

}
