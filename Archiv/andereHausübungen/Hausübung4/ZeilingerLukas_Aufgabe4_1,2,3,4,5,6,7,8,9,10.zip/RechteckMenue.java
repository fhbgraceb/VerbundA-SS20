package zeilingerLukas_4;

import java.util.Scanner;

public class RechteckMenue {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int eingabe = -1;
		double seite_a = 0;
		double seite_b = 0;
		System.out.print("Geben Sie die Länge für die Seite a ein: ");
		seite_a = scan.nextInt();
		System.out.print("Geben Sie die Länge für die Seite b ein: ");
		seite_b = scan.nextInt();
		
		while (eingabe != 0)
		{
			System.out.println("-----------------------------------");
			System.out.println("---- Was möchten Sie berechnen ----");
			System.out.println("1...Umfang");
			System.out.println("2...Fläche");
			System.out.println("3...Diagonale");
			System.out.println("0...Programm beenden :(");
			System.out.println("-----------------------------------");
			eingabe = scan.nextInt();
			
			switch(eingabe)
			{
			case 1: System.out.println("Der Umfang beträgt: " + Umfang(seite_a,seite_b)); break;
			case 2: System.out.println("Die Fläche beträgt: " + Flaeche(seite_a,seite_b)); break;
			case 3: System.out.println("Die Diagonalen betragen: " + Math.round(Diagonale(seite_a,seite_b)*1000f)/1000f); break;
			case 0: break;
			default: System.out.println("Falsche Eingabe"); break;
			}	
		}
		System.out.println("This is the End...");
	}
	public static double Flaeche (double a,double b)
	{
		double flaeche = a * b;
		return flaeche;
	}
	public static double Umfang (double a,double b)
	{
		double umfang = (2*a) + (2*b);
		return umfang;
	}
	public static double Diagonale (double a,double b)
	{
		double diagonale = Math.sqrt((a*a)+(b*b));
		return diagonale;
	}

}
