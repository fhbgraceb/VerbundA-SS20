package zeilingerLukas_4;

import java.util.Scanner;

public class Eintritt {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		int alter = 0;
		final int mindestalter = 16;
		final int eintrittspreis = 10;
		final int bestechungsgeld = 50;
		double geldVorhanden = 0;
		
		System.out.print("Wie alt sind Sie?");
		alter = scan.nextInt();
		System.out.print("Wieviel Geld haben Sie");
		geldVorhanden = scan.nextDouble();
		
		
	}
	public static String KommstDuRein(int alter, int eintrittspreis, int bestechungsgeld, double geld, int mindestalter)
	{
		String ausgabe = " ";
		
		if (alter >= mindestalter && geld >= eintrittspreis) ausgabe = "Du kommst hinein!";
		else if (alter < mindestalter && geld >= bestechungsgeld) ausgabe = "Du kommst hinein!";
		else ausgabe = "Du kummst da ned rein";
		
		return ausgabe;
	}

}
