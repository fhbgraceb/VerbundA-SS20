package zeilingerLukas_4;

import java.util.Scanner;

public class Einkommenssteuer1 {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		double Geld = 0;
		
		System.out.print("Geben Sie das Jahreseinkommen ein:");
		Geld = scan.nextDouble();
		
		if (Geld > 10000) 
		{
			System.out.println("Es muss leider Einkommenssteuer gezahlt werden :( ");
		}
		else {
			System.out.println("Wuhuuu du musst nichts zahlen :D ");
		}
	}

}
