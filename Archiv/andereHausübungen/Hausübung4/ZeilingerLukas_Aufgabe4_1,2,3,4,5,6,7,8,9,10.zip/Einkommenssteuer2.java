package zeilingerLukas_4;

import java.util.Scanner;

public class Einkommenssteuer2 {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		double jahreseinkommen = 0;
		
		System.out.print("Geben Sie Ihr Jahreseinkommen ein: ");
		jahreseinkommen = scan.nextDouble();
		
		if(jahreseinkommen <= 1000) System.out.println("Sie zahlen nichts an das Finanzamt!");
		if(jahreseinkommen > 1000 && jahreseinkommen <= 2000) System.out.println("Sie zahlen "+(jahreseinkommen*0.1)+"€ an das Finanzamt!");
		if(jahreseinkommen > 1000 && jahreseinkommen <= 2000) System.out.println("Sie zahlen "+(jahreseinkommen*0.1)+"€ an das Finanzamt!");
	}

}
