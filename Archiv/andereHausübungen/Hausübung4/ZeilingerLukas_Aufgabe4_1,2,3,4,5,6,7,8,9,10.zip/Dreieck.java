package zeilingerLukas_4;

import java.util.Scanner;

public class Dreieck {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner (System.in);
		double a = 0;
		double b = 0;
		double c = 0;
		
		System.out.print("Geben Sie die Seitelänge für a ein: ");
		a = scan.nextDouble();
		System.out.print("Geben Sie die Seitelänge für b ein: ");
		b = scan.nextDouble();
		System.out.print("Geben Sie die Seitelänge für c ein: ");
		c = scan.nextDouble();
		
		if(a > 0 && b > 0 && c > 0 && (a+b) > c && (b+c) > a && (a+c) > b )
		{
			if (a == b && b == c)
			{
				System.out.println("Gleichseitiges Dreieck!");
			}
			else 
			{
				if (a == b || b == c || c == a)
				{
					if((a*a+b*b == c*c) || (c*c + b*b == a*a) || (a*a + c*c == b*b) )
					{
						System.out.println("Gleichschenkeliges und Rechtwinkeliges Dreieck!");
					}
					else
					{
						System.out.println("Gleichschenkeliges Dreieck!");
					}
				}
				else 
				{
					if((a*a+b*b == c*c) || (c*c + b*b == a*a) || (a*a + c*c == b*b) )
					{
						System.out.println("Rechtwinkeliges Dreieck!");
					}
					else
					{
						System.out.println("Normales Dreieck!");
					}
				}
			}
			
			
		}
		else
		{
			System.out.println("Kein Dreieck!");
		}
	}

}
