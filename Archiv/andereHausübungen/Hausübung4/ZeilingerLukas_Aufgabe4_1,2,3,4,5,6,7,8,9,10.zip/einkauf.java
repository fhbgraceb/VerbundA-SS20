package zeilingerLukas_4;

import java.util.Scanner;

public class einkauf {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		double Geld = 0;
		double Preis = 0;
		
		Geld = scan.nextDouble();
		Preis = scan.nextDouble();
		
		if(Geld >= Preis)
		{
			System.out.println("U can buy it amana");
		}
		else {
			System.out.println("Not enough money nigga");
		}
		

	}

}
