package zeilingerLukas_4;

import java.util.Scanner;

public class Regenschirm {

	public static void main(String[] args) 
	{
		String eingabe = "";
		String ausgabe = "";
		int counter = 0;
		boolean regen = false;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Regnet es draußen (Ja,Nein)");
		eingabe = scan.next();
		
		if(eingabe.equals("Ja"))
		{
			regen = true;
			counter++;
		}
		else if(eingabe.equals("Nein"))
		{
			regen = false;
			counter++;
		}
		else
		{
			ausgabe = "Keine Ahnung was du gesagt hast :(";
		}
		
		if(regen == true && counter > 0)
		{
			ausgabe = "Regenschirm nicht vergessen!";
		}
		else if (regen == false && counter > 0)
		{
			ausgabe ="Du brauchst heute keinen Regenschirm :)";
		}
		System.out.println(ausgabe);
	}

}
