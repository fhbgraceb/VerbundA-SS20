package zeilingerLukas_4;

import java.util.Scanner;

public class Teiler {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int zahl1 = 0;
		int zahl2 = 0;
		
		System.out.print("Geben Sie die 1. Zahl ein: ");
		zahl1 = scan.nextInt();
		System.out.print("Geben Sie die 2. Zahl ein: ");
		zahl2 = scan.nextInt();
		
		if (zahl1 % zahl2 == 0)
		{
			System.out.println(zahl2+" ist ein Teiler von "+zahl1);
		}
		else
		{
			System.out.println(zahl2+" ist kein Teiler von "+zahl1);
		}
		

	}

}
