package zeilingerLukas_4;

import java.util.Scanner;

public class Bierversand {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int liter = 0;
		int fassungsvermögen = 0;
		double zwischenvar = 0.0;
		int benoetigteFaesser = 0;

		System.out.print("Geben Sie das Fassungsvermoegen pro Fass an: ");
		fassungsvermögen = scan.nextInt();
		System.out.print("Geben Sie die gewuenschte Bestellmenge in Liter an: ");
		liter = scan.nextInt();
		
		zwischenvar = Math.ceil((double)liter / (double)fassungsvermögen);
		benoetigteFaesser = (int) zwischenvar;
		
		System.out.println("Sie brauchen "+benoetigteFaesser+ " Faesser!");
	}

}
