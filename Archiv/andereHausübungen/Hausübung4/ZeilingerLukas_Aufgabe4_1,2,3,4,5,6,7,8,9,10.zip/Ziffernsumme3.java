package zeilingerLukas_4;

import java.util.Scanner;

public class Ziffernsumme3 {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		String zahl = "";
		int ziffernsumme = 0;
		final int teiler = 3;
		
		System.out.print("Geben Sie eine 3 Stellige Zahl ein: ");
		zahl = scan.next();
		char[] ziffern = zahl.toCharArray();
		
		if (ziffern.length != 3) 
		{
			System.out.println("Die eingegebene Zahl ist NICHT 3 Stellen lang!");
		}
		else 
		{
			ziffernsumme = (int)ziffern[0] + (int)ziffern[1] + (int)ziffern[2];
			
			if(ziffernsumme % 3 == 0)
			{
				System.out.println("Die Zahl "+zahl+" ist teilbar durch 3");
			}
			else
			{
				System.out.println("Die Zahl "+zahl+" ist NICHT teilbar durch 3");
			}
		}
		
	}

}
