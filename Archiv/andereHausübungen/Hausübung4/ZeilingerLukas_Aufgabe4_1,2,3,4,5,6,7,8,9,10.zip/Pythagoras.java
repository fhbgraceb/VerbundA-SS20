package zeilingerLukas_4;

import java.util.Scanner;

public class Pythagoras {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int a;
		int b;
		int c;
		
		System.out.print("Geben Sie a ein: ");
		a = scan.nextInt();
		System.out.print("Geben Sie b ein: ");
		b = scan.nextInt();
		System.out.print("Geben Sie c ein: ");
		c = scan.nextInt();
		
		if((a*a)+(b*b)==(c*c) || (b*b)+(c*c)==(a*a) || (a*a) + (c*c) == (b*b))
		{
			System.out.println("Das ist ein rechtwinkeliges Dreieck!");
		}
		else
		{
			System.out.println("Das ist viel aber KEIN rechtwinkeliges Dreieck!");
		}

	}

}
